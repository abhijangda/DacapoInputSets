/**
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.geronimo.connector.outbound.security;

import java.util.Map;
import java.util.HashMap;

import javax.resource.spi.ManagedConnectionFactory;

import org.apache.geronimo.connector.outbound.ManagedConnectionFactoryWrapper;
import org.apache.geronimo.security.jaas.LoginModuleGBean;
import net.sf.cglib.beans.BeanMap;

/**
 * @version $Rev: 562593 $ $Date: 2007-08-03 22:39:52 +0100 (Fri, 03 Aug 2007) $
 */
public class PasswordCredentialLoginModuleWrapper extends LoginModuleGBean {
    public static final String MANAGED_CONNECTION_FACTORY_OPTION = "geronimo.managedconnectionfactory.option";

    public PasswordCredentialLoginModuleWrapper(String loginModuleClass, String objectName, boolean wrapPrincipals, Map<String, Object> options, String loginDomainName, ManagedConnectionFactoryWrapper managedConnectionFactoryWrapper, ClassLoader classLoader) {
        super(loginModuleClass, objectName, wrapPrincipals, getOptions(options, managedConnectionFactoryWrapper), loginDomainName, classLoader);
    }

    private static Map<String, Object> getOptions(Map<String, Object> options, ManagedConnectionFactoryWrapper managedConnectionFactoryWrapper) {
        if (options == null) {
            options = new HashMap<String, Object>();
        }
        ManagedConnectionFactory managedConnectionFactory = managedConnectionFactoryWrapper.$getManagedConnectionFactory();
        options.put(MANAGED_CONNECTION_FACTORY_OPTION, managedConnectionFactory);
        return options;
    }

}
